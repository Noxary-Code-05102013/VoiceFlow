package com.voiceflow.android;

import android.Manifest;
import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public final class MainActivity extends Activity {
    private static final int REQUEST_AUDIO = 100;
    private static final int REQUEST_NOTIFICATIONS = 101;
    private boolean launchWhenReady;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        showSetupScreen();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (launchWhenReady) {
            launchWhenReady = false;
            startWhenPermitted();
        }
    }

    private void showSetupScreen() {
        int padding = dp(24);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(padding, dp(42), padding, padding);
        content.setBackgroundColor(0xFF111514);

        TextView title = new TextView(this);
        title.setText(R.string.setup_title);
        title.setTextColor(0xFFEDF2EE);
        title.setTextSize(26);
        title.setGravity(Gravity.START);
        content.addView(title);

        TextView description = new TextView(this);
        description.setText(R.string.setup_description);
        description.setTextColor(0xFFB8C2BA);
        description.setTextSize(15);
        description.setLineSpacing(dp(4), 1f);
        LinearLayout.LayoutParams descriptionParams = new LinearLayout.LayoutParams(-1, -2);
        descriptionParams.topMargin = dp(14);
        content.addView(description, descriptionParams);

        addPermissionInfo(content, R.string.permission_overlay_title, R.string.permission_overlay_detail);
        addPermissionInfo(content, R.string.permission_whatsapp_title, R.string.permission_whatsapp_detail);
        addPermissionInfo(content, R.string.permission_microphone_title, R.string.permission_microphone_detail);

        Button start = new Button(this);
        start.setText(R.string.setup_start_button);
        start.setOnClickListener(view -> beginPermissionFlow());
        LinearLayout.LayoutParams buttonParams = new LinearLayout.LayoutParams(-1, -2);
        buttonParams.topMargin = dp(24);
        content.addView(start, buttonParams);

        TextView note = new TextView(this);
        note.setText(R.string.webgpu_note);
        note.setTextColor(0xFF87938A);
        note.setTextSize(12);
        LinearLayout.LayoutParams noteParams = new LinearLayout.LayoutParams(-1, -2);
        noteParams.topMargin = dp(14);
        content.addView(note, noteParams);

        setContentView(content);
    }

    private void addPermissionInfo(LinearLayout parent, int heading, int detail) {
        TextView label = new TextView(this);
        label.setText(getString(R.string.permission_info_format, getString(heading), getString(detail)));
        label.setTextColor(0xFFD8E1DA);
        label.setTextSize(14);
        label.setLineSpacing(dp(3), 1f);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
        params.topMargin = dp(18);
        parent.addView(label, params);
    }

    private void beginPermissionFlow() {
        launchWhenReady = true;
        if (!Settings.canDrawOverlays(this)) {
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
            startActivity(intent);
            return;
        }
        if (!hasAudioPermission()) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQUEST_AUDIO);
            return;
        }
        if (!isAccessibilityEnabled()) {
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            return;
        }
        requestNotificationPermissionOrStart();
    }

    private void startWhenPermitted() {
        if (!Settings.canDrawOverlays(this) || !hasAudioPermission() || !isAccessibilityEnabled()) {
            showSetupScreen();
            return;
        }
        requestNotificationPermissionOrStart();
    }

    private void requestNotificationPermissionOrStart() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQUEST_NOTIFICATIONS);
            return;
        }
        startOverlay();
    }

    private void startOverlay() {
        Intent intent = new Intent(this, FloatingOverlayService.class).setAction(FloatingOverlayService.ACTION_SHOW);
        startForegroundService(intent);
        finish();
    }

    private boolean hasAudioPermission() {
        return checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
    }

    private boolean isAccessibilityEnabled() {
        String enabledServices = Settings.Secure.getString(getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        if (TextUtils.isEmpty(enabledServices)) return false;
        ComponentName service = new ComponentName(this, VoiceAccessibilityService.class);
        return enabledServices.contains(service.flattenToString());
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_AUDIO && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            if (!isAccessibilityEnabled()) {
                launchWhenReady = true;
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            } else {
                requestNotificationPermissionOrStart();
            }
        }
        if (requestCode == REQUEST_NOTIFICATIONS) startOverlay();
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}