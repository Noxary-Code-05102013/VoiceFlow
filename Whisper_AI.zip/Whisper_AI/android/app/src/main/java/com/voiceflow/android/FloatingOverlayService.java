package com.voiceflow.android;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.webkit.WebViewAssetLoader;

public final class FloatingOverlayService extends Service {
    public static final String ACTION_SHOW = "com.voiceflow.android.SHOW";
    public static final String ACTION_CLOSE = "com.voiceflow.android.CLOSE";
    private static final String CHANNEL_ID = "voiceflow-floating";
    private static final int NOTIFICATION_ID = 42;

    private WindowManager windowManager;
    private View overlay;
    private WebView webView;
    private WindowManager.LayoutParams layoutParams;
    private boolean floatingMode;

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        startForeground(NOTIFICATION_ID, buildNotification());
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_CLOSE.equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (Settings.canDrawOverlays(this)) showOverlay();
        else stopSelf();
        return START_STICKY;
    }

    private void showOverlay() {
        if (overlay != null) return;
        int width = dp(390);
        int height = dp(720);
        int screenWidth = getResources().getDisplayMetrics().widthPixels;
        int screenHeight = getResources().getDisplayMetrics().heightPixels;
        width = Math.min(width, screenWidth - dp(20));
        height = Math.min(height, screenHeight - dp(100));

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setBackgroundColor(Color.rgb(17, 21, 20));
        panel.setElevation(dp(12));

        LinearLayout titleBar = new DraggableHeader(this);
        titleBar.setGravity(Gravity.CENTER_VERTICAL);
        titleBar.setPadding(dp(14), dp(8), dp(8), dp(8));
        titleBar.setBackgroundColor(Color.rgb(24, 29, 27));
        TextView title = new TextView(this);
        title.setText(R.string.voiceflow_brand);
        title.setTextColor(Color.rgb(237, 242, 238));
        title.setTextSize(15);
        title.setTypeface(null, Typeface.BOLD);
        titleBar.addView(title, new LinearLayout.LayoutParams(0, dp(40), 1));
        Button close = new Button(this);
        close.setText(R.string.close_button);
        close.setTextSize(10);
        close.setOnClickListener(view -> stopSelf());
        titleBar.addView(close, new LinearLayout.LayoutParams(-2, dp(40)));
        Button floatToggle = new Button(this);
        floatToggle.setText(R.string.float_button);
        floatToggle.setTextSize(10);
        floatToggle.setOnClickListener(view -> toggleFloatingMode(floatToggle));
        titleBar.addView(floatToggle, new LinearLayout.LayoutParams(-2, dp(40)));
        panel.addView(titleBar, new LinearLayout.LayoutParams(-1, dp(52)));
        titleBar.setClickable(true);
        titleBar.setOnClickListener(view -> toggleFloatingMode(floatToggle));
        titleBar.setOnTouchListener(new DragListener());

        webView = new WebView(this);
        configureWebView(webView);
        panel.addView(webView, new LinearLayout.LayoutParams(-1, 0, 1));

        layoutParams = new WindowManager.LayoutParams(
                width,
                height,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                    | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                    | WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
        layoutParams.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
        layoutParams.y = dp(36);
        overlay = panel;
        windowManager.addView(overlay, layoutParams);
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void configureWebView(WebView view) {
        WebViewAssetLoader assetLoader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();
        WebSettings settings = view.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        view.addJavascriptInterface(new AndroidBridge(), "AndroidVoiceFlow");
        view.setWebViewClient(new WebViewClient() {
            @Override
            public android.webkit.WebResourceResponse shouldInterceptRequest(WebView webView, WebResourceRequest request) {
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView webView, WebResourceRequest request) {
                Uri uri = request.getUrl();
                return !"appassets.androidplatform.net".equals(uri.getHost());
            }

            @Override
            public boolean onRenderProcessGone(WebView webView, RenderProcessGoneDetail detail) {
                Toast.makeText(FloatingOverlayService.this, R.string.webview_restarted_toast, Toast.LENGTH_LONG).show();
                stopSelf();
                return true;
            }
        });
        view.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(PermissionRequest request) {
                boolean requestsAudio = false;
                for (String resource : request.getResources()) {
                    if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(resource)) requestsAudio = true;
                    else {
                        request.deny();
                        return;
                    }
                }
                if (requestsAudio && checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                    request.grant(new String[]{PermissionRequest.RESOURCE_AUDIO_CAPTURE});
                } else {
                    request.deny();
                    Toast.makeText(FloatingOverlayService.this, R.string.microphone_permission_missing, Toast.LENGTH_LONG).show();
                }
            }
        });
        view.loadUrl("https://appassets.androidplatform.net/assets/index.html");
    }

    private void toggleFloatingMode(Button toggleButton) {
        floatingMode = !floatingMode;
        toggleButton.setText(floatingMode ? R.string.expand_button : R.string.float_button);
        int screenWidth = getResources().getDisplayMetrics().widthPixels;
        int screenHeight = getResources().getDisplayMetrics().heightPixels;
        layoutParams.width = Math.min(dp(floatingMode ? 330 : 390), screenWidth - dp(20));
        layoutParams.height = floatingMode
                ? dp(190)
                : Math.min(dp(720), screenHeight - dp(100));
        windowManager.updateViewLayout(overlay, layoutParams);
        webView.evaluateJavascript(
                "document.body.classList.toggle('is-floating', " + floatingMode + ")",
                null);
    }

    private final class AndroidBridge {
        @android.webkit.JavascriptInterface
        public void onTextReady(String text) {
            if (text == null || text.trim().isEmpty()) return;
            boolean inserted = VoiceAccessibilityService.insertIntoWhatsApp(text);
                runOnMain(() -> Toast.makeText(FloatingOverlayService.this,
                    inserted ? R.string.inserted_toast : R.string.target_field_missing_toast,
                    Toast.LENGTH_LONG).show());
        }
    }

    private void runOnMain(Runnable action) {
        android.os.Handler handler = new android.os.Handler(getMainLooper());
        handler.post(action);
    }

    private final class DragListener implements View.OnTouchListener {
        private int startX;
        private int startY;
        private float touchX;
        private float touchY;
        private boolean dragged;

        @Override
        public boolean onTouch(View view, MotionEvent event) {
            if (event.getAction() == MotionEvent.ACTION_DOWN) {
                startX = layoutParams.x;
                startY = layoutParams.y;
                touchX = event.getRawX();
                touchY = event.getRawY();
                dragged = false;
                return true;
            }
            if (event.getAction() == MotionEvent.ACTION_MOVE) {
                int deltaX = Math.round(event.getRawX() - touchX);
                int deltaY = Math.round(event.getRawY() - touchY);
                dragged |= Math.abs(deltaX) > dp(4) || Math.abs(deltaY) > dp(4);
                layoutParams.x = startX + deltaX;
                layoutParams.y = startY + deltaY;
                windowManager.updateViewLayout(overlay, layoutParams);
                return true;
            }
            if (event.getAction() == MotionEvent.ACTION_UP) {
                if (!dragged) view.performClick();
                return true;
            }
            return false;
        }
    }

    private static final class DraggableHeader extends LinearLayout {
        DraggableHeader(Context context) {
            super(context);
        }

        @Override
        public boolean performClick() {
            super.performClick();
            return true;
        }
    }

    private void createNotificationChannel() {
        NotificationChannel channel = new NotificationChannel(CHANNEL_ID, getString(R.string.overlay_channel_name), NotificationManager.IMPORTANCE_LOW);
        getSystemService(NotificationManager.class).createNotificationChannel(channel);
    }

    private Notification buildNotification() {
        Intent closeIntent = new Intent(this, FloatingOverlayService.class).setAction(ACTION_CLOSE);
        PendingIntent closePendingIntent = PendingIntent.getService(this, 1, closeIntent,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder builder = new Notification.Builder(this, CHANNEL_ID);
        return builder.setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle(getString(R.string.overlay_notification_title))
                .setContentText(getString(R.string.overlay_notification_text))
                .setOngoing(true)
                .addAction(new Notification.Action.Builder(null, "Schließen", closePendingIntent).build())
                .build();
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    @Override
    public void onDestroy() {
        if (overlay != null) {
            windowManager.removeView(overlay);
            overlay = null;
        }
        if (webView != null) {
            webView.removeJavascriptInterface("AndroidVoiceFlow");
            webView.destroy();
            webView = null;
        }
        stopForeground(STOP_FOREGROUND_REMOVE);
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}