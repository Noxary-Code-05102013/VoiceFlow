package com.voiceflow.android;

import android.accessibilityservice.AccessibilityService;
import android.os.Bundle;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;

public final class VoiceAccessibilityService extends AccessibilityService {
    private static final String WHATSAPP = "com.whatsapp";
    private static final String WHATSAPP_BUSINESS = "com.whatsapp.w4b";
    private static volatile VoiceAccessibilityService instance;
    private int lastWhatsAppWindowId = -1;

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null || event.getPackageName() == null) return;
        String packageName = event.getPackageName().toString();
        if (isWhatsApp(packageName) && event.getWindowId() >= 0) {
            lastWhatsAppWindowId = event.getWindowId();
        }
    }

    @Override
    public void onInterrupt() {
    }

    @Override
    public void onDestroy() {
        if (instance == this) instance = null;
        super.onDestroy();
    }

    static boolean insertIntoWhatsApp(String text) {
        VoiceAccessibilityService service = instance;
        return service != null && service.insertFocusedText(text);
    }

    private boolean insertFocusedText(String dictatedText) {
        if (dictatedText == null || dictatedText.trim().isEmpty()) return false;
        for (AccessibilityWindowInfo window : getWindows()) {
            if (lastWhatsAppWindowId >= 0 && window.getId() != lastWhatsAppWindowId) continue;
            AccessibilityNodeInfo root = window.getRoot();
            if (root == null) continue;
            try {
                if (!isWhatsApp(root.getPackageName() == null ? "" : root.getPackageName().toString())) continue;
                AccessibilityNodeInfo focused = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT);
                if (focused == null || !focused.isEditable()) {
                    if (focused != null) focused.recycle();
                    focused = findFocusedEditable(root);
                }
                if (focused == null) continue;
                try {
                    CharSequence current = focused.getText();
                    String existing = current == null ? "" : current.toString();
                    int selectionStart = focused.getTextSelectionStart();
                    int selectionEnd = focused.getTextSelectionEnd();
                    boolean hasSelection = selectionStart >= 0 && selectionEnd >= selectionStart && selectionEnd <= existing.length();
                    int insertStart = hasSelection ? selectionStart : existing.length();
                    int insertEnd = hasSelection ? selectionEnd : existing.length();
                        String prefix = existing.substring(0, insertStart);
                        String suffix = existing.substring(insertEnd);
                        String separatorBefore = prefix.isEmpty() || prefix.endsWith(" ") || prefix.endsWith("\n") ? "" : " ";
                        String separatorAfter = suffix.isEmpty() || suffix.startsWith(" ") || suffix.startsWith("\n") ? "" : " ";
                        String insertion = separatorBefore + dictatedText.trim() + separatorAfter;
                    String updated = existing.substring(0, insertStart) + insertion + existing.substring(insertEnd);
                    Bundle arguments = new Bundle();
                    arguments.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, updated);
                    if (!focused.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, arguments)) continue;
                    int cursor = insertStart + insertion.length();
                    Bundle selection = new Bundle();
                    selection.putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_START_INT, cursor);
                    selection.putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_END_INT, cursor);
                    focused.performAction(AccessibilityNodeInfo.ACTION_SET_SELECTION, selection);
                    return true;
                } finally {
                    focused.recycle();
                }
            } finally {
                root.recycle();
            }
        }
        return false;
    }

    private AccessibilityNodeInfo findFocusedEditable(AccessibilityNodeInfo node) {
        if (node.isFocused() && node.isEditable()) return AccessibilityNodeInfo.obtain(node);
        for (int index = 0; index < node.getChildCount(); index++) {
            AccessibilityNodeInfo child = node.getChild(index);
            if (child == null) continue;
            AccessibilityNodeInfo match = findFocusedEditable(child);
            child.recycle();
            if (match != null) return match;
        }
        return null;
    }

    private static boolean isWhatsApp(String packageName) {
        return WHATSAPP.equals(packageName) || WHATSAPP_BUSINESS.equals(packageName);
    }
}