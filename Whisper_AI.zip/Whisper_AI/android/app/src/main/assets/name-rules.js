export function findMatchingNameRule(text, rules) {
  return [...rules]
    .sort((left, right) => right.name.length - left.name.length)
    .find(({ name }) => {
      const escapedName = name.replace(/[.*+?^${}()|[\]\\]/gu, '\\$&');
      return new RegExp(`(^|[^\\p{L}\\p{N}])${escapedName}([^\\p{L}\\p{N}]|$)`, 'iu').test(text);
    });
}