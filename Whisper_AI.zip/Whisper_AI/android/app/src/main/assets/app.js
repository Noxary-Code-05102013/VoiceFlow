import { findMatchingNameRule } from './name-rules.js';

const MODELS = {
  whisper: 'onnx-community/whisper-base',
};
const STYLE_NAMES = { standard: 'Standard', casual: 'Locker', professional: 'Professionell', short: 'Kurz' };
const MAX_NAME_RULES = 12;
const MAX_NAME_LENGTH = 32;
const MAX_NAME_PROMPT_LENGTH = 120;
const savedNameRules = (() => {
  try {
    const parsed = JSON.parse(localStorage.getItem('voiceflow-name-rules') || '[]');
    if (!Array.isArray(parsed)) return [];
    return parsed
      .filter((rule) => typeof rule?.name === 'string' && typeof rule?.prompt === 'string')
      .map((rule) => ({
        name: rule.name.trim().slice(0, MAX_NAME_LENGTH),
        prompt: rule.prompt.trim().slice(0, MAX_NAME_PROMPT_LENGTH),
      }))
      .filter((rule) => rule.name && rule.prompt)
      .slice(0, MAX_NAME_RULES);
  } catch {
    return [];
  }
})();
const state = {
  profile: localStorage.getItem('voiceflow-profile') || 'adult',
  style: localStorage.getItem('voiceflow-style') || 'standard',
  nameRules: savedNameRules,
  recording: false,
  busy: false,
  recorder: null,
  stream: null,
  chunks: [],
  whisper: null,
  writer: null,
  whisperBackend: 'wasm',
  writerBackend: null,
  transformers: null,
  progress: { whisper: 0, writer: 0 },
  deferredInstall: null,
  toastTimer: null,
};

const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => [...document.querySelectorAll(selector)];
const micButton = $('#mic-button');
const recordingDock = $('#recording-dock');
const resultText = $('#result-text');
if (new URLSearchParams(window.location.search).get('floating') === '1') {
  document.body.classList.add('is-floating');
}

function setStatus(message, { error = false, working = false } = {}) {
  const banner = $('#status-banner');
  $('#status-message').textContent = message;
  banner.hidden = !message;
  banner.classList.toggle('is-error', error);
  const editorState = $('#editor-state');
  editorState.classList.toggle('is-working', working);
  if (message) setEditorLabel(working ? 'Verarbeitung läuft' : error ? 'Aktion erforderlich' : 'Bereit zum Diktieren');
}

function setEditorLabel(label) {
  $('#editor-state').lastChild.textContent = label;
}

function showToast(message) {
  const toast = $('#toast');
  toast.textContent = message;
  toast.classList.add('is-visible');
  clearTimeout(state.toastTimer);
  state.toastTimer = setTimeout(() => toast.classList.remove('is-visible'), 2300);
}

function updateWordCount() {
  const count = resultText.value.trim() ? resultText.value.trim().split(/\s+/u).length : 0;
  $('#word-count').textContent = `${count} ${count === 1 ? 'Wort' : 'Wörter'}`;
  const hasText = Boolean(resultText.value.trim());
  $('#copy-button').disabled = !hasText;
  $('#clear-button').disabled = !hasText;
  $('#retry-button').disabled = !hasText || state.busy;
}

function updateProfile() {
  const adult = state.profile === 'adult';
  $('#profile-name').textContent = adult ? 'Erwachsen' : 'Kind';
  $('#profile-avatar').textContent = adult ? 'E' : 'K';
  $('#top-avatar').textContent = adult ? 'E' : 'K';
  $('#profile-style').textContent = `${STYLE_NAMES[state.style]}stil`;
  $$('[data-profile]').forEach((button) => {
    const selected = button.dataset.profile === state.profile;
    button.setAttribute('aria-pressed', String(selected));
  });
  $$('[data-style]').forEach((button) => {
    const selected = button.dataset.style === state.style;
    button.classList.toggle('is-selected', selected);
    button.setAttribute('aria-pressed', String(selected));
  });
  $('#settings-style').value = state.style;
}

function renderNameRules() {
  const list = $('#name-rule-list');
  list.replaceChildren();
  state.nameRules.forEach((rule, index) => {
    const item = document.createElement('div');
    item.className = 'name-rule-item';
    const copy = document.createElement('div');
    copy.className = 'name-rule-item-copy';
    const name = document.createElement('strong');
    name.textContent = rule.name;
    const prompt = document.createElement('span');
    prompt.textContent = rule.prompt;
    const remove = document.createElement('button');
    remove.className = 'name-rule-remove';
    remove.type = 'button';
    remove.textContent = 'Entfernen';
    remove.setAttribute('aria-label', `Regel für ${rule.name} entfernen`);
    remove.addEventListener('click', () => {
      state.nameRules.splice(index, 1);
      localStorage.setItem('voiceflow-name-rules', JSON.stringify(state.nameRules));
      renderNameRules();
    });
    copy.append(name, prompt);
    item.append(copy, remove);
    list.append(item);
  });
  $('#name-rule-limit').textContent = state.nameRules.length >= MAX_NAME_RULES
    ? `Maximal ${MAX_NAME_RULES} Regeln gespeichert. Entferne eine Regel, um eine neue hinzuzufügen.`
    : `Noch ${MAX_NAME_RULES - state.nameRules.length} von ${MAX_NAME_RULES} Regeln verfügbar. Regeln werden nur angewendet, wenn der Name im Diktat vorkommt.`;
  $('#name-rule-form').querySelector('[type="submit"]').disabled = state.nameRules.length >= MAX_NAME_RULES;
}

function setView(view) {
  const views = { write: $('#write-view'), settings: $('#settings-view'), privacy: $('#privacy-view') };
  Object.entries(views).forEach(([key, element]) => { element.hidden = key !== view; });
  const labels = { write: 'Diktat', settings: 'Einstellungen', privacy: 'Datenschutz' };
  $('#page-title').textContent = labels[view];
  $$('[data-view]').forEach((button) => {
    const selected = button.dataset.view === view;
    button.classList.toggle('is-active', selected);
    if (button.matches('.nav-item,.mobile-nav-item')) {
      if (selected) button.setAttribute('aria-current', 'page');
      else button.removeAttribute('aria-current');
    }
  });
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

async function getTransformers() {
  if (state.transformers) return state.transformers;
  setStatus('Lade lokale Inferenzbibliothek. Beim ersten Mal ist eine Internetverbindung nötig.', { working: true });
  try {
    state.transformers = await import('https://cdn.jsdelivr.net/npm/@huggingface/transformers@4.3.0');
    state.transformers.env.useBrowserCache = true;
    state.transformers.env.allowLocalModels = false;
    return state.transformers;
  } catch (error) {
    console.error(error);
    throw new Error('Die Modellbibliothek konnte nicht geladen werden. Prüfe deine Internetverbindung und lade die Seite erneut.');
  }
}

function updateProgress(kind, data) {
  if (typeof data?.progress === 'number') state.progress[kind] = Math.max(0, Math.min(100, data.progress));
  else if (typeof data?.loaded === 'number' && typeof data?.total === 'number' && data.total > 0) state.progress[kind] = Math.round(data.loaded / data.total * 100);
  const current = kind === 'whisper' ? 'Whisper Base' : 'Textmodell';
  const percentage = Math.max(0, Math.min(100, Math.round(state.progress[kind])));
  $('#progress-label').textContent = `${current} wird lokal geladen …`;
  $('#progress-percent').textContent = `${percentage}%`;
  $('#progress-bar').style.width = `${percentage}%`;
  $('#model-progress-wrap').hidden = false;
}

async function createPipeline(task, model, options) {
  const { pipeline } = await getTransformers();
  try {
    return await pipeline(task, model, options);
  } catch (error) {
    if (options.device !== 'webgpu') throw error;
    console.warn(`${task} WebGPU initialisation failed; retrying with WASM.`, error);
    state.whisperBackend = 'wasm';
    updateDeviceLabels();
    return pipeline(task, model, { ...options, device: 'wasm', dtype: 'q4' });
  }
}

async function ensureModelCapacity() {
  if (!navigator.storage?.estimate) return;
  try {
    const { quota, usage = 0 } = await navigator.storage.estimate();
    const available = (quota || 0) - usage;
    if (quota && available < 600 * 1024 * 1024) {
      throw new Error('Im Browserspeicher sind weniger als 600 MB frei. Schaffe Speicherplatz und versuche den Modelldownload erneut.');
    }
  } catch (error) {
    if (error instanceof Error && error.message.includes('weniger als 600 MB')) throw error;
    console.warn('Browser storage estimate is unavailable:', error);
  }
}

async function loadWhisper() {
  if (state.whisper) return state.whisper;
  const gpuAvailable = Boolean(navigator.gpu);
  const device = gpuAvailable ? 'webgpu' : 'wasm';
  state.whisperBackend = device;
  updateDeviceLabels();
  $('#whisper-model-status').textContent = 'Modell wird geladen …';
  $('#load-models-button').disabled = true;
  try {
    await ensureModelCapacity();
    state.whisper = await createPipeline('automatic-speech-recognition', MODELS.whisper, {
      device,
      dtype: 'q4',
      progress_callback: (data) => updateProgress('whisper', data),
    });
    $('#whisper-model-status').textContent = 'Bereit · lokal im Browsercache';
    $('#progress-bar').style.width = '100%';
    $('#progress-percent').textContent = '100%';
    return state.whisper;
  } catch (error) {
    state.whisper = null;
    $('#whisper-model-status').textContent = 'Download oder Initialisierung fehlgeschlagen';
    throw new Error(error?.message?.includes('Internet') ? error.message : 'Whisper Base konnte nicht geladen werden. Prüfe die Internetverbindung und den freien Speicher.');
  } finally {
    $('#load-models-button').disabled = false;
  }
}

async function loadWriter() {
  if (state.writer) return state.writer;
  if (!navigator.gpu) {
    throw new Error('LFM2.5 benötigt WebGPU. Dieser Browser unterstützt die lokale Textformulierung nicht.');
  }
  $('#llm-model-status').textContent = 'Textmodell wird geladen …';
  $('#load-models-button').disabled = true;
  try {
    await ensureModelCapacity();
    const { createLfmRewriter } = await import('./lfm-rewriter.js');
    state.writer = await createLfmRewriter({
      onStatus: (message) => {
        $('#llm-model-status').textContent = message;
        $('#progress-label').textContent = message;
        $('#progress-percent').textContent = '';
        $('#progress-track').classList.add('is-indeterminate');
        $('#model-progress-wrap').hidden = false;
      },
    });
    state.writerBackend = 'webgpu';
    $('#llm-model-status').textContent = 'Bereit · Q4 quantisiert · lokal im Browsercache';
    $('#progress-track').classList.remove('is-indeterminate');
    return state.writer;
  } catch (error) {
    state.writer = null;
    $('#llm-model-status').textContent = 'Download oder Initialisierung fehlgeschlagen';
    $('#progress-track').classList.remove('is-indeterminate');
    throw error;
  } finally {
    $('#load-models-button').disabled = false;
  }
}

async function loadModels() {
  setStatus('Modelle werden einmalig heruntergeladen und lokal vorbereitet. Das kann je nach Verbindung etwas dauern.', { working: true });
  $('#load-models-button').disabled = true;
  $('#progress-label').textContent = 'Modelle werden vorbereitet …';
  $('#model-progress-wrap').hidden = false;
  try {
    await loadWhisper();
    await loadWriter();
    $('#whisper-model-status').textContent = 'Bereit · lokal im Browsercache';
    $('#llm-model-status').textContent = 'Bereit · Q4 quantisiert · lokal im Browsercache';
    $('#progress-label').textContent = 'Beide Modelle sind bereit';
    $('#progress-percent').textContent = '100%';
    $('#progress-bar').style.width = '100%';
    $('#engine-note').textContent = `Lokal bereit · LFM WebGPU · Whisper ${state.whisperBackend === 'webgpu' ? 'WebGPU' : 'WASM'}`;
    setStatus('Die lokalen Modelle sind bereit. Deine Sprache und Texte bleiben auf diesem Gerät.');
    showToast('Modelle sind bereit.');
  } catch (error) {
    setStatus(error.message, { error: true });
  } finally {
    $('#load-models-button').disabled = false;
  }
}

function updateDeviceLabels() {
  const gpuAvailable = Boolean(navigator.gpu);
  const deviceMemory = navigator.deviceMemory;
  $('#hardware-mode').textContent = state.writerBackend ? 'WebGPU · LFM' : gpuAvailable ? 'WebGPU verfügbar' : 'LFM benötigt WebGPU';
  $('#device-kind').textContent = /Mobi|Android|iPhone|iPad/i.test(navigator.userAgent) ? 'Mobil' : 'Desktop';
  $('#microphone-status').textContent = navigator.mediaDevices?.getUserMedia ? 'Verfügbar' : 'Nicht unterstützt';
  $('#memory-status').textContent = deviceMemory ? `ca. ${deviceMemory} GB RAM` : 'Vom Browser verborgen';
  $('#footer-device').textContent = deviceMemory && deviceMemory < 4 ? 'Wenig RAM · kleines Modell' : 'Lokale Verarbeitung';
  $('#connection-label').textContent = navigator.onLine ? (state.whisper && state.writer ? 'Lokal bereit' : 'Modelle bei Bedarf') : (state.whisper && state.writer ? 'Offline · Modelle bereit' : 'Offline · Modelle fehlen');
  $('#engine-note').textContent = state.whisper && state.writer ? `Lokal bereit · LFM WebGPU · Whisper ${state.whisperBackend === 'webgpu' ? 'WebGPU' : 'WASM'}` : (gpuAvailable ? 'WebGPU verfügbar · Modelle bei Bedarf' : 'LFM benötigt WebGPU');
}

function friendlyMicError(error) {
  if (error?.name === 'NotAllowedError' || error?.name === 'PermissionDeniedError') return 'Mikrofonzugriff verweigert. Erlaube den Zugriff in den Browser-Einstellungen und versuche es erneut.';
  if (error?.name === 'NotFoundError' || error?.name === 'DevicesNotFoundError') return 'Kein Mikrofon gefunden. Schließe ein Mikrofon an und versuche es erneut.';
  if (error?.name === 'NotReadableError') return 'Das Mikrofon wird gerade von einer anderen App verwendet.';
  return 'Das Mikrofon konnte nicht gestartet werden. Nutze VoiceFlow über HTTPS oder localhost und prüfe deine Browserberechtigungen.';
}

async function startRecording() {
  if (!navigator.mediaDevices?.getUserMedia || !window.MediaRecorder) {
    setStatus('Dein Browser unterstützt lokale Audioaufnahme nicht vollständig. Bitte verwende einen aktuellen Browser über HTTPS.', { error: true });
    return;
  }
  try {
    state.stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true, channelCount: 1 } });
    const mimeType = ['audio/webm;codecs=opus', 'audio/mp4', 'audio/webm'].find((type) => MediaRecorder.isTypeSupported(type));
    state.recorder = mimeType ? new MediaRecorder(state.stream, { mimeType }) : new MediaRecorder(state.stream);
    state.chunks = [];
    state.recorder.addEventListener('dataavailable', (event) => { if (event.data.size) state.chunks.push(event.data); });
    state.recorder.addEventListener('stop', processRecording, { once: true });
    state.recorder.start(250);
    state.recording = true;
    recordingDock.classList.add('is-recording');
    micButton.setAttribute('aria-label', 'Aufnahme stoppen');
    micButton.title = 'Aufnahme stoppen';
    $('#recording-title').textContent = 'Ich höre dir zu …';
    $('#recording-subtitle').textContent = 'Sprich natürlich. Tippe erneut, wenn du fertig bist.';
    setEditorLabel('Aufnahme läuft');
    $('#editor-state').classList.add('is-working');
    setStatus('Aufnahme läuft auf deinem Gerät. Audio wird nicht hochgeladen.');
  } catch (error) {
    console.error(error);
    setStatus(friendlyMicError(error), { error: true });
  }
}

function stopRecording() {
  if (!state.recorder || state.recorder.state === 'inactive') return;
  state.recording = false;
  state.recorder.stop();
  state.stream?.getTracks().forEach((track) => track.stop());
  state.stream = null;
  recordingDock.classList.remove('is-recording');
  micButton.setAttribute('aria-label', 'Aufnahme starten');
  micButton.title = 'Aufnahme starten';
  $('#recording-title').textContent = 'Verarbeite dein Diktat …';
  $('#recording-subtitle').textContent = 'Whisper und das Textmodell laufen lokal auf deinem Gerät.';
  setEditorLabel('Sprache wird erkannt');
  $('#editor-state').classList.add('is-working');
  setStatus('Dein Diktat wird lokal erkannt und formuliert. Die Erkennung kann je nach Gerät einige Sekunden dauern.', { working: true });
}

function resampleAudio(input, sourceRate, targetRate = 16000) {
  if (sourceRate === targetRate) return input;
  const ratio = sourceRate / targetRate;
  const outputLength = Math.floor(input.length / ratio);
  const output = new Float32Array(outputLength);
  for (let i = 0; i < outputLength; i += 1) {
    const position = i * ratio;
    const left = Math.floor(position);
    const fraction = position - left;
    const right = Math.min(left + 1, input.length - 1);
    output[i] = input[left] * (1 - fraction) + input[right] * fraction;
  }
  return output;
}

async function decodeAudio(blob) {
  const AudioContextClass = window.AudioContext || window.webkitAudioContext;
  if (!AudioContextClass) throw new Error('Dein Browser kann die Audioaufnahme nicht lokal verarbeiten.');
  const context = new AudioContextClass();
  try {
    const decoded = await context.decodeAudioData(await blob.arrayBuffer());
    const mono = new Float32Array(decoded.length);
    for (let channel = 0; channel < decoded.numberOfChannels; channel += 1) {
      const values = decoded.getChannelData(channel);
      for (let i = 0; i < values.length; i += 1) mono[i] += values[i] / decoded.numberOfChannels;
    }
    return resampleAudio(mono, decoded.sampleRate);
  } finally {
    await context.close();
  }
}

function buildWritingPrompt(transcript) {
  const profile = state.profile === 'adult'
    ? 'Erwachsenen gegenüber respektvoll und natürlich; nicht ungefragt „Hey“ verwenden.'
    : 'Für ein Kind klar und freundlich schreiben, ohne zu verniedlichen.';
  const styles = { standard: 'Natürlich und korrekt.', casual: 'Freundlich und locker.', professional: 'Höflich und professionell.', short: 'Knapp, ohne Informationen wegzulassen.' };
  const nameRule = findMatchingNameRule(transcript, state.nameRules);
  const personalStyle = nameRule
    ? `Zusätzlicher kurzer Stilwunsch für ${nameRule.name}: ${nameRule.prompt}. Erfinde dadurch keine neuen Inhalte.`
    : '';
  return [
    {
      role: 'system',
      content: `Formuliere den deutschen diktierten Satz als kurze, natürliche Nachricht. Bewahre Namen, Zahlen, Zeiten und Aussage exakt. Erfinde nichts und füge keine Erklärungen oder zusätzlichen Sätze hinzu. Korrigiere Grammatik und Satzzeichen. ${profile} Stil: ${styles[state.style]} ${personalStyle} Gib nur die vollständige Nachricht aus. Beispiel: „Schreibe Tim, dass ich 10 Minuten zu spät komme“ -> „Hallo Tim, ich komme 10 Minuten zu spät.“`,
    },
    { role: 'user', content: transcript },
  ];
}

function preserveCriticalNumbers(original, rewritten) {
  const numbers = original.match(/\d+(?:[.:]\d+)?/gu) || [];
  const missing = numbers.filter((number) => !rewritten.includes(number));
  if (missing.length) {
    throw new Error('Die Formulierung ließ eine Zahl aus. Dein ursprüngliches Diktat bleibt erhalten; bitte prüfe den Text oder formuliere ihn erneut.');
  }
  const timeWords = /\b(?:heute|morgen|gestern|vorgestern|nachher|später|gleich)\b/giu;
  const sourceTimeWords = new Set((original.match(timeWords) || []).map((word) => word.toLocaleLowerCase('de-DE')));
  const addedTimeWord = (rewritten.match(timeWords) || []).find((word) => !sourceTimeWords.has(word.toLocaleLowerCase('de-DE')));
  if (addedTimeWord) {
    throw new Error('Die Formulierung hat eine nicht diktierte Zeitangabe ergänzt. Dein ursprünglicher Text bleibt erhalten; bitte prüfe ihn.');
  }
}

async function processRecording() {
  const blob = new Blob(state.chunks, { type: state.recorder?.mimeType || 'audio/webm' });
  state.chunks = [];
  if (!blob.size) {
    resetRecordingUi();
    setStatus('Es wurde keine Audioaufnahme erkannt. Prüfe das Mikrofon und versuche es erneut.', { error: true });
    return;
  }
  state.busy = true;
  updateWordCount();
  try {
    const audio = await decodeAudio(blob);
    const whisper = await loadWhisper();
    const recognized = await whisper(audio, { sampling_rate: 16000, return_timestamps: false, chunk_length_s: 20, stride_length_s: 3 });
    const transcript = recognized?.text?.trim();
    if (!transcript) throw new Error('Ich habe keine Sprache erkannt. Sprich etwas näher am Mikrofon und versuche es erneut.');
    const writer = await loadWriter();
    const [systemMessage] = buildWritingPrompt(transcript);
    const output = await writer.rewrite({
      systemPrompt: systemMessage.content,
      text: transcript,
      onUpdate: (partial) => {
        resultText.value = partial;
        resultText.dispatchEvent(new Event('input', { bubbles: true }));
      },
    });
    preserveCriticalNumbers(transcript, output);
    resultText.value = output;
    resultText.dispatchEvent(new Event('input', { bubbles: true }));
    window.AndroidVoiceFlow?.onTextReady(output);
    resultText.classList.remove('result-appear');
    requestAnimationFrame(() => resultText.classList.add('result-appear'));
    $('#recording-title').textContent = 'Dein Text ist fertig';
    $('#recording-subtitle').textContent = 'Lokal erkannt und formuliert. Du kannst den Text direkt bearbeiten.';
    $('#engine-note').textContent = `Lokal verarbeitet · LFM WebGPU · Whisper ${state.whisperBackend === 'webgpu' ? 'WebGPU' : 'WASM'}`;
    setStatus('Fertig. Dein Text wurde vollständig auf diesem Gerät verarbeitet.');
    setEditorLabel('Lokal verarbeitet');
  } catch (error) {
    console.error(error);
    setStatus(error.message || 'Die lokale Verarbeitung ist fehlgeschlagen. Prüfe die Modelleinstellungen und versuche es erneut.', { error: true });
    $('#recording-title').textContent = 'Diktat nicht verarbeitet';
    $('#recording-subtitle').textContent = 'Prüfe die Meldung und versuche es erneut.';
  } finally {
    state.busy = false;
    resetRecordingUi(false);
    updateWordCount();
  }
}

function resetRecordingUi(resetTitle = true) {
  recordingDock.classList.remove('is-recording');
  micButton.setAttribute('aria-label', 'Aufnahme starten');
  micButton.title = 'Aufnahme starten';
  if (resetTitle) {
    $('#recording-title').textContent = 'Bereit, wenn du es bist';
    $('#recording-subtitle').textContent = 'Tippe auf das Mikrofon und sprich ganz natürlich';
  }
  $('#editor-state').classList.remove('is-working');
}

async function reformulate() {
  const original = resultText.value.trim();
  if (!original || state.busy) return;
  state.busy = true;
  updateWordCount();
  setStatus('Dein Text wird lokal neu formuliert …', { working: true });
  try {
    const writer = await loadWriter();
    const [systemMessage] = buildWritingPrompt(original);
    const output = await writer.rewrite({
      systemPrompt: systemMessage.content,
      text: original,
      onUpdate: (partial) => {
        resultText.value = partial;
        resultText.dispatchEvent(new Event('input', { bubbles: true }));
      },
    });
    preserveCriticalNumbers(original, output);
    resultText.value = output;
    resultText.dispatchEvent(new Event('input', { bubbles: true }));
    window.AndroidVoiceFlow?.onTextReady(output);
    setStatus('Dein Text wurde lokal neu formuliert.');
    setEditorLabel('Lokal verarbeitet');
  } catch (error) {
    console.error(error);
    setStatus(error.message, { error: true });
  } finally {
    state.busy = false;
    updateWordCount();
  }
}

micButton.addEventListener('click', () => {
  if (state.busy) return;
  if (state.recording) stopRecording();
  else startRecording();
});
$('#load-models-button').addEventListener('click', loadModels);
$('#retry-button').addEventListener('click', reformulate);
$('#clear-button').addEventListener('click', () => {
  resultText.value = '';
  resultText.dispatchEvent(new Event('input', { bubbles: true }));
  $('#recording-title').textContent = 'Bereit, wenn du es bist';
  $('#recording-subtitle').textContent = 'Tippe auf das Mikrofon und sprich ganz natürlich';
  setStatus('');
  setEditorLabel('Bereit zum Diktieren');
});
$('#copy-button').addEventListener('click', async () => {
  try {
    await navigator.clipboard.writeText(resultText.value);
    showToast('Text kopiert.');
  } catch {
    resultText.focus();
    resultText.select();
    showToast('Text markiert. Kopiere ihn über das Menü deines Geräts.');
  }
});
$('#banner-close').addEventListener('click', () => { $('#status-banner').hidden = true; });
resultText.addEventListener('input', updateWordCount);
$$('[data-view]').forEach((button) => button.addEventListener('click', () => setView(button.dataset.view)));
$$('[data-profile]').forEach((button) => button.addEventListener('click', () => {
  state.profile = button.dataset.profile;
  localStorage.setItem('voiceflow-profile', state.profile);
  updateProfile();
}));
$$('[data-style]').forEach((button) => button.addEventListener('click', () => {
  state.style = button.dataset.style;
  localStorage.setItem('voiceflow-style', state.style);
  updateProfile();
}));
$('#settings-style').addEventListener('change', (event) => {
  state.style = event.target.value;
  localStorage.setItem('voiceflow-style', state.style);
  updateProfile();
});
$('#name-rule-prompt').addEventListener('input', (event) => {
  $('#name-rule-count').textContent = `${event.target.value.length} / ${MAX_NAME_PROMPT_LENGTH}`;
});
$('#name-rule-form').addEventListener('submit', (event) => {
  event.preventDefault();
  const name = $('#name-rule-name').value.trim().slice(0, MAX_NAME_LENGTH);
  const prompt = $('#name-rule-prompt').value.trim().slice(0, MAX_NAME_PROMPT_LENGTH);
  if (!name || !prompt) return;
  const existingIndex = state.nameRules.findIndex((rule) => rule.name.toLocaleLowerCase('de-DE') === name.toLocaleLowerCase('de-DE'));
  if (existingIndex === -1 && state.nameRules.length >= MAX_NAME_RULES) {
    showToast(`Du kannst maximal ${MAX_NAME_RULES} Namensregeln speichern.`);
    return;
  }
  const rule = { name, prompt };
  if (existingIndex === -1) state.nameRules.push(rule);
  else state.nameRules[existingIndex] = rule;
  localStorage.setItem('voiceflow-name-rules', JSON.stringify(state.nameRules));
  event.currentTarget.reset();
  $('#name-rule-count').textContent = `0 / ${MAX_NAME_PROMPT_LENGTH}`;
  renderNameRules();
  showToast(`Schreibregel für ${name} gespeichert.`);
});
window.addEventListener('beforeinstallprompt', (event) => {
  event.preventDefault();
  state.deferredInstall = event;
  $('#install-button').hidden = false;
});
$('#install-button').addEventListener('click', async () => {
  if (!state.deferredInstall) return;
  state.deferredInstall.prompt();
  await state.deferredInstall.userChoice;
  state.deferredInstall = null;
  $('#install-button').hidden = true;
});
window.addEventListener('online', updateDeviceLabels);
window.addEventListener('offline', updateDeviceLabels);

updateProfile();
renderNameRules();
updateWordCount();
updateDeviceLabels();
if ('serviceWorker' in navigator && location.protocol !== 'file:') {
  navigator.serviceWorker.register('./sw.js').catch((error) => console.warn('Offline shell registration failed:', error));
}