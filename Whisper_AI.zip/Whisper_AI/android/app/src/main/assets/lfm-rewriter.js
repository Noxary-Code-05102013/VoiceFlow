const MODEL_ID = 'LiquidAI/LFM2.5-350M-ONNX';
const MODEL_BASE = `https://huggingface.co/${MODEL_ID}/resolve/main`;
const MODEL_FILE = 'onnx/model_q4.onnx';
const MODEL_DATA_FILE = 'onnx/model_q4.onnx_data';
const MAX_NEW_TOKENS = 64;
const TEMPERATURE = 0.1;
const TOP_K = 50;
const REPETITION_PENALTY = 1.05;
const HIDDEN_SIZE = 1024;
const NUM_KV_HEADS = 8;
const HEAD_DIM = 64;

export async function createLfmRewriter({ onStatus = () => {} } = {}) {
  onStatus('LFM-Tokenizer und WebGPU-Laufzeit werden geladen …');
  if (!navigator.gpu) {
    throw new Error('LFM2.5 benötigt WebGPU. Dieser Browser bietet es nicht an; verwende einen aktuellen Browser mit GPU-Beschleunigung.');
  }

  const adapter = await navigator.gpu.requestAdapter();
  if (!adapter) {
    throw new Error('Für LFM2.5 wurde kein WebGPU-Adapter gefunden. Prüfe die GPU-Beschleunigung deines Browsers.');
  }

  const [{ AutoTokenizer }, ort] = await Promise.all([
    import('https://cdn.jsdelivr.net/npm/@huggingface/transformers@4.3.0'),
    import('https://cdn.jsdelivr.net/npm/onnxruntime-web@1.30.0/dist/ort.webgpu.min.mjs'),
  ]);
  ort.env.wasm.numThreads = 1;

  onStatus('LFM-Tokenizer wird geladen …');
  const tokenizer = await AutoTokenizer.from_pretrained(MODEL_ID);

  onStatus('LFM Q4-Gewichte werden geladen (ca. 294 MB) …');
  const session = await ort.InferenceSession.create(`${MODEL_BASE}/${MODEL_FILE}`, {
    executionProviders: ['webgpu'],
    externalData: [{ path: 'model_q4.onnx_data', data: `${MODEL_BASE}/${MODEL_DATA_FILE}` }],
  });

  function createCache() {
    const cache = {};
    for (const name of session.inputNames) {
      if (name.startsWith('past_conv')) {
        cache[name] = new ort.Tensor('float32', new Float32Array(HIDDEN_SIZE * 3), [1, HIDDEN_SIZE, 3]);
      } else if (name.startsWith('past_key_values')) {
        cache[name] = new ort.Tensor('float32', new Float32Array(0), [1, NUM_KV_HEADS, 0, HEAD_DIM]);
      }
    }
    return cache;
  }

  function selectToken(logits, generatedTokens) {
    const repeated = new Set(generatedTokens);
    const topScores = new Float32Array(TOP_K).fill(Number.NEGATIVE_INFINITY);
    const topTokenIds = new Int32Array(TOP_K);
    let candidateCount = 0;
    for (let tokenId = 0; tokenId < logits.length; tokenId += 1) {
      let score = logits[tokenId];
      if (repeated.has(tokenId)) score = score > 0 ? score / REPETITION_PENALTY : score * REPETITION_PENALTY;
      score /= TEMPERATURE;
      if (candidateCount < TOP_K) {
        let index = candidateCount;
        candidateCount += 1;
        while (index > 0) {
          const parent = Math.floor((index - 1) / 2);
          if (topScores[parent] <= score) break;
          topScores[index] = topScores[parent];
          topTokenIds[index] = topTokenIds[parent];
          index = parent;
        }
        topScores[index] = score;
        topTokenIds[index] = tokenId;
      } else if (score > topScores[0]) {
        let index = 0;
        while (true) {
          const left = index * 2 + 1;
          if (left >= TOP_K) break;
          const right = left + 1;
          const smallerChild = right < TOP_K && topScores[right] < topScores[left] ? right : left;
          if (topScores[smallerChild] >= score) break;
          topScores[index] = topScores[smallerChild];
          topTokenIds[index] = topTokenIds[smallerChild];
          index = smallerChild;
        }
        topScores[index] = score;
        topTokenIds[index] = tokenId;
      }
    }
    let maxScore = Number.NEGATIVE_INFINITY;
    for (let index = 0; index < candidateCount; index += 1) maxScore = Math.max(maxScore, topScores[index]);
    const weights = new Float32Array(candidateCount);
    let totalWeight = 0;
    for (let index = 0; index < candidateCount; index += 1) {
      weights[index] = Math.exp(topScores[index] - maxScore);
      totalWeight += weights[index];
    }
    let selection = Math.random() * totalWeight;
    for (let index = 0; index < candidateCount; index += 1) {
      selection -= weights[index];
      if (selection <= 0) return topTokenIds[index];
    }
    return topTokenIds[candidateCount - 1];
  }

  function disposeUncachedOutputs(outputs, cache) {
    const cached = new Set(Object.values(cache));
    for (const tensor of Object.values(outputs)) {
      if (!cached.has(tensor)) tensor.dispose();
    }
  }

  async function rewrite({ systemPrompt, text, onUpdate = () => {} }) {
    const prompt = tokenizer.apply_chat_template([
      { role: 'system', content: systemPrompt },
      { role: 'user', content: text },
    ], { add_generation_prompt: true, tokenize: false });
    const inputIds = tokenizer.encode(prompt, { add_special_tokens: false });
    if (!inputIds.length) throw new Error('Der LFM-Tokenizer konnte den Diktattext nicht verarbeiten.');

    const cache = createCache();
    const generatedTokens = [];
    let currentLength = inputIds.length;
    let ids = inputIds;
    try {
      for (let step = 0; step < MAX_NEW_TOKENS; step += 1) {
        const inputTensor = new ort.Tensor('int64', new BigInt64Array(ids.map(BigInt)), [1, ids.length]);
        const attentionMask = new ort.Tensor('int64', new BigInt64Array(currentLength).fill(1n), [1, currentLength]);
        const numLogitsToKeep = new ort.Tensor('int64', BigInt64Array.of(1n), []);
        let outputs;
        try {
          outputs = await session.run({ input_ids: inputTensor, attention_mask: attentionMask, num_logits_to_keep: numLogitsToKeep, ...cache });
        } finally {
          inputTensor.dispose();
          attentionMask.dispose();
          numLogitsToKeep.dispose();
        }

        const logits = outputs.logits;
        const vocabularySize = logits.dims[2];
        const lastLogits = logits.data.slice((logits.dims[1] - 1) * vocabularySize, logits.dims[1] * vocabularySize);
        const nextToken = selectToken(lastLogits, generatedTokens);
        generatedTokens.push(nextToken);

        for (const [name, tensor] of Object.entries(outputs)) {
          let cacheName = null;
          if (name.startsWith('present_conv')) cacheName = name.replace('present_conv', 'past_conv');
          else if (name.startsWith('present.')) cacheName = name.replace('present.', 'past_key_values.');
          if (cacheName && cache[cacheName]) {
            cache[cacheName].dispose();
            cache[cacheName] = tensor;
          }
        }
        disposeUncachedOutputs(outputs, cache);

        if (nextToken === tokenizer.eos_token_id) break;
        const partial = tokenizer.decode(generatedTokens, { skip_special_tokens: true }).trim();
        if (partial) onUpdate(partial);
        ids = [nextToken];
        currentLength += 1;
      }
      const result = tokenizer.decode(generatedTokens, { skip_special_tokens: true })
        .replace(/\s*---+\s*[\s\S]*$/u, '')
        .replace(/[ \t]+/gu, ' ')
        .replace(/\s*\n\s*/gu, ' ')
        .trim();
      if (!result || result.length > 3000) throw new Error('LFM hat keine passende Formulierung geliefert. Bitte versuche es erneut.');
      return result;
    } finally {
      for (const tensor of Object.values(cache)) tensor.dispose();
    }
  }

  onStatus('LFM2.5 ist lokal bereit.');
  return { rewrite };
}