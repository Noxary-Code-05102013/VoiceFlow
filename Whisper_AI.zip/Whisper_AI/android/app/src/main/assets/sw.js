const CACHE_NAME = 'voiceflow-shell-v9';
const MODEL_CACHE_NAME = 'voiceflow-models-v1';
const APP_SHELL = ['./', './index.html', './styles.css', './model-progress.css', './app.js', './lfm-rewriter.js', './name-rules.js', './manifest.json', './icons/voiceflow.svg'];
const MODEL_FILE_PATTERN = /\.(onnx(?:_data)?|safetensors|bin|wasm)(\?|$)/i;

async function migrateModelFiles(cacheNames) {
  const modelCache = await caches.open(MODEL_CACHE_NAME);
  for (const name of cacheNames.filter((key) => key.startsWith('voiceflow-shell-') && key !== CACHE_NAME)) {
    const oldCache = await caches.open(name);
    for (const request of await oldCache.keys()) {
      if (!MODEL_FILE_PATTERN.test(new URL(request.url).pathname)) continue;
      const response = await oldCache.match(request);
      if (response) await modelCache.put(request, response);
    }
  }
}

self.addEventListener('install', (event) => {
  event.waitUntil(caches.open(CACHE_NAME).then((cache) => cache.addAll(APP_SHELL)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', (event) => {
  event.waitUntil(caches.keys().then(async (keys) => {
    await migrateModelFiles(keys);
    await Promise.all(keys.filter((key) => key.startsWith('voiceflow-shell-') && key !== CACHE_NAME).map((key) => caches.delete(key)));
    await self.clients.claim();
  }));
});

self.addEventListener('fetch', (event) => {
  const request = event.request;
  if (request.method !== 'GET' || request.headers.has('range')) return;
  const url = new URL(request.url);
  const isModelFile = MODEL_FILE_PATTERN.test(url.pathname);
  const isRuntimeAsset = url.hostname === 'cdn.jsdelivr.net' && url.pathname.includes('/npm/');
  if (url.origin !== self.location.origin && !isModelFile && !isRuntimeAsset) return;

  if (url.origin === self.location.origin) {
    event.respondWith(caches.match(request).then((cached) => cached || fetch(request).then((response) => {
      if (response.ok && response.type === 'basic') {
        const copy = response.clone();
        caches.open(CACHE_NAME).then((cache) => cache.put(request, copy));
      }
      return response;
    }).catch(() => caches.match('./index.html'))));
    return;
  }

  if ((isModelFile || isRuntimeAsset) && request.mode !== 'no-cors') {
    const cacheName = isModelFile ? MODEL_CACHE_NAME : CACHE_NAME;
    event.respondWith(caches.open(cacheName).then((cache) => cache.match(request)).then((cached) => cached || fetch(request).then((response) => {
      const contentType = response.headers.get('content-type') || '';
      const isCacheableRuntime = isRuntimeAsset && /javascript|wasm/i.test(contentType);
      if (response.ok && response.type === 'cors' && (isModelFile || isCacheableRuntime)) {
        const copy = response.clone();
        caches.open(cacheName).then((cache) => cache.put(request, copy).catch(() => {}));
      }
      return response;
    })));
  }
});